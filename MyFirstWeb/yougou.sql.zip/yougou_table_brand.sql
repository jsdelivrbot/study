
-- --------------------------------------------------------

--
-- 表的结构 `brand`
--

CREATE TABLE `brand` (
  `brand_id` int(11) NOT NULL,
  `brand_name` varchar(30) NOT NULL,
  `brand_logo` varchar(60) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='品牌信息';

--
-- 转存表中的数据 `brand`
--

INSERT INTO `brand` (`brand_id`, `brand_name`, `brand_logo`) VALUES
(1, '百丽', '../img/belle.jpg'),
(2, '他她', '../img/tata.jpg'),
(3, '天美意', '../img/teenmix.jpg'),
(4, '百思图', '../img/basto.jpg'),
(5, '思加图', '../img/staccato.jpg'),
(6, '森达', '../img/senda.jpg'),
(7, '妙丽', '../img/millies.jpg'),
(8, '真美思', '../img/joypeace.jpg'),
(9, '拔佳', '../img/bata.jpg'),
(10, '暇步士', '../img/hushpuppies.jpg');
