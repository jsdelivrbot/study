
-- --------------------------------------------------------

--
-- 表的结构 `user_goodscar`
--

CREATE TABLE `user_goodscar` (
  `car_id` int(20) NOT NULL,
  `car_goodsNum` int(3) DEFAULT NULL,
  `total_price` float DEFAULT NULL,
  `user_id` int(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `user_goodscar`
--

INSERT INTO `user_goodscar` (`car_id`, `car_goodsNum`, `total_price`, `user_id`) VALUES
(1001, 0, 0, 0);
