
-- --------------------------------------------------------

--
-- 表的结构 `index_info`
--

CREATE TABLE `index_info` (
  `goods_id` int(11) NOT NULL,
  `goods_name` varchar(500) NOT NULL,
  `goods_img` varchar(500) NOT NULL,
  `goods_type` varchar(500) NOT NULL,
  `activity` varchar(500) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `index_info`
--

INSERT INTO `index_info` (`goods_id`, `goods_name`, `goods_img`, `goods_type`, `activity`) VALUES
(1, '他她', 'goodsImg/womenbig.jpg', 'womenC', '夏季新上第四波'),
(2, '天美意', 'goodsImg/women1.jpg', 'women', '若是不羁2折起'),
(3, '他她', 'goodsImg/women2.jpg', 'women', '玩转潮流新上'),
(4, '思加图', 'goodsImg/women3.jpg', 'women', '活力觉醒'),
(5, '百思图', 'goodsImg/women4.jpg', 'women', '2018年新款'),
(6, '真美诗', 'goodsImg/women5.jpg', 'women', '缤纷夏日'),
(7, '拔佳', 'goodsImg/women6.jpg', 'women', '夏日换新'),
(8, '森达', 'goodsImg/manbig.jpg', 'manC', '潮绅姿态'),
(9, '拔佳', 'goodsImg/man1.jpg', 'man', '夏季出游潮搭'),
(10, '百丽', 'goodsImg/man2.jpg', 'man', '专柜同款'),
(11, '暇步士', 'goodsImg/man3.jpg', 'man', '美式休闲时尚'),
(12, '天美意', 'goodsImg/man4.jpg', 'man', '有型出街'),
(13, '他她', 'goodsImg/man5.jpg', 'man', '潮流一夏'),
(14, '卡特', 'goodsImg/man6.jpg', 'man', '潮品工装'),
(15, 'T恤', 'goodsImg/sportsbig.jpg', 'sportsC', '无Tee不欢'),
(16, '跑步鞋', 'goodsImg/sports1.jpg', 'sports', '爽酷夏季'),
(17, '紧身服', 'goodsImg/sports2.jpg', 'sports', '干爽透气面料'),
(18, '短裤', 'goodsImg/sports3.jpg', 'sports', '初夏新风尚'),
(19, '彪马', 'goodsImg/sports4.jpg', 'sports', '拒绝不型'),
(20, '耐克', 'goodsImg/sports5.jpg', 'sports', '初夏新活力'),
(21, '阿迪休闲', 'goodsImg/sports6.jpg', 'sports', '解锁时尚穿搭'),
(22, '阿迪达斯', 'goodsImg/childrenbig.jpg', 'childrenC', '夏季换新'),
(23, '耐克', 'goodsImg/children1.jpg', 'children', '潮童鞋服'),
(24, '三叶草', 'goodsImg/children2.jpg', 'children', '限时优惠'),
(25, '跑步鞋', 'goodsImg/children3.jpg', 'children', '运动健将'),
(26, 'T恤', 'goodsImg/children4.jpg', 'children', '夏日主打'),
(27, '休闲鞋', 'goodsImg/children5.jpg', 'children', '新款上市'),
(28, '复刻鞋', 'goodsImg/children6.jpg', 'children', '百搭鞋款');
