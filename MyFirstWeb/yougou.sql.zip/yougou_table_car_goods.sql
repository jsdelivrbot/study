
-- --------------------------------------------------------

--
-- 表的结构 `car_goods`
--

CREATE TABLE `car_goods` (
  `car_goodsId` int(20) NOT NULL,
  `goods_name` varchar(500) DEFAULT NULL,
  `goods_img` varchar(500) DEFAULT NULL,
  `goods_color` varchar(50) DEFAULT NULL,
  `goods_size` int(10) DEFAULT NULL,
  `goods_price` float DEFAULT NULL,
  `goods_num` int(11) DEFAULT NULL,
  `goodsTotalPrice` float NOT NULL,
  `car_id` int(20) DEFAULT NULL,
  `goods_id` int(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `car_goods`
--

INSERT INTO `car_goods` (`car_goodsId`, `goods_name`, `goods_img`, `goods_color`, `goods_size`, `goods_price`, `goods_num`, `goodsTotalPrice`, `car_id`, `goods_id`) VALUES
(37, 'Belle/百丽夏专柜同款白色时尚舒适羊皮女凉拖R5K1DBT7', 'belleImg/100496719_01_mb.jpg', '白色', 37, 543.9, 5, 2719.5, 1001, 3);
