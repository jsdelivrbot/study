
--
-- Indexes for dumped tables
--

--
-- Indexes for table `allbrand`
--
ALTER TABLE `allbrand`
  ADD PRIMARY KEY (`brand_id`);

--
-- Indexes for table `belle_goods`
--
ALTER TABLE `belle_goods`
  ADD PRIMARY KEY (`goods_id`);

--
-- Indexes for table `brand`
--
ALTER TABLE `brand`
  ADD PRIMARY KEY (`brand_id`);

--
-- Indexes for table `car_goods`
--
ALTER TABLE `car_goods`
  ADD PRIMARY KEY (`car_goodsId`);

--
-- Indexes for table `index_info`
--
ALTER TABLE `index_info`
  ADD PRIMARY KEY (`goods_id`);

--
-- Indexes for table `user_goodscar`
--
ALTER TABLE `user_goodscar`
  ADD PRIMARY KEY (`car_id`);

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`u_id`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `allbrand`
--
ALTER TABLE `allbrand`
  MODIFY `brand_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
--
-- 使用表AUTO_INCREMENT `belle_goods`
--
ALTER TABLE `belle_goods`
  MODIFY `goods_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=181;
--
-- 使用表AUTO_INCREMENT `brand`
--
ALTER TABLE `brand`
  MODIFY `brand_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- 使用表AUTO_INCREMENT `car_goods`
--
ALTER TABLE `car_goods`
  MODIFY `car_goodsId` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;
--
-- 使用表AUTO_INCREMENT `user_goodscar`
--
ALTER TABLE `user_goodscar`
  MODIFY `car_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1002;
--
-- 使用表AUTO_INCREMENT `user_info`
--
ALTER TABLE `user_info`
  MODIFY `u_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;