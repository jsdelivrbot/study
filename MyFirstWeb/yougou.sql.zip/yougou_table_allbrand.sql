
-- --------------------------------------------------------

--
-- 表的结构 `allbrand`
--

CREATE TABLE `allbrand` (
  `brand_id` int(11) NOT NULL,
  `brand_name` varchar(500) NOT NULL,
  `brand_logo` varchar(500) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `allbrand`
--

INSERT INTO `allbrand` (`brand_id`, `brand_name`, `brand_logo`) VALUES
(1, '百思图', 'brandImg/adidas507638809.jpg'),
(2, '百思图', 'brandImg/adidasclassic507604745.jpg'),
(3, '百思图', 'brandImg/adidasneo507638832.jpg'),
(4, '百思图', 'brandImg/asics507610277.jpg'),
(5, '百思图', 'brandImg/bata507639265.jpg'),
(6, '百思图', 'brandImg/belle507639379.jpg'),
(7, '百思图', 'brandImg/cat507636509.jpg'),
(8, '百思图', 'brandImg/converse506750560.jpg'),
(9, '百思图', 'brandImg/crocs507644176.jpg'),
(10, '百思图', 'brandImg/fato2.jpg'),
(11, '百思图', 'brandImg/gzh2.jpg'),
(12, '百思图', 'brandImg/hushpuppies507610094.jpg'),
(13, '百思图', 'brandImg/innet474093564.jpg'),
(14, '百思图', 'brandImg/joypeace468306549.jpg'),
(15, '百思图', 'brandImg/millies527742673.jpg'),
(16, '百思图', 'brandImg/puma507639858.jpg'),
(17, '百思图', 'brandImg/reebok534338687.jpg'),
(18, '百思图', 'brandImg/senda506405009.jpg'),
(19, '百思图', 'brandImg/skechers507606504.jpg'),
(20, '百思图', 'brandImg/staccato507605520.jpg'),
(21, '百思图', 'brandImg/tata544791364.jpg'),
(22, '百思图', 'brandImg/teenmix507609543.jpg'),
(23, '百思图', 'brandImg/thenorthface507728112.jpg'),
(24, '百思图', 'brandImg/timberland507609698.jpg'),
(25, '百思图', 'brandImg/vans506406901.jpg'),
(26, '百思图', 'brandImg/adidas507638809.jpg'),
(27, '百思图', 'brandImg/adidasclassic507604745.jpg');
