
-- --------------------------------------------------------

--
-- 表的结构 `user_info`
--

CREATE TABLE `user_info` (
  `u_id` int(11) NOT NULL,
  `u_name` varchar(20) DEFAULT NULL,
  `u_password` varchar(18) NOT NULL,
  `u_tel` varchar(11) DEFAULT NULL,
  `u_email` varchar(40) DEFAULT NULL,
  `u_carId` int(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `user_info`
--

INSERT INTO `user_info` (`u_id`, `u_name`, `u_password`, `u_tel`, `u_email`, `u_carId`) VALUES
(4, NULL, '123456789', '18874483598', NULL, 1004),
(3, NULL, '1452365', '18778843586', NULL, 1003),
(5, NULL, '1452361', NULL, '', 1002),
(1, '骆凤姣', '123abc', '18874483595', '812199449@qq.com', 1001),
(6, NULL, '123456789', NULL, '155448255@qq.com.edjac', 6);
